Hotspot for Chromebooks website

Publish with GitHub Pages:
1. Sign in at https://github.com/
2. Create a new PUBLIC repository named hotspot-for-chromebooks
3. Choose Add file > Upload files and upload index.html
4. Commit the changes.
5. Open Settings > Pages.
6. Under Build and deployment, select Deploy from a branch.
7. Choose branch main and folder /(root), then Save.
8. Wait a few minutes and use the URL shown in Settings > Pages.

Note: the page is an information guide. A public website link alone cannot share your Chromebook's internet connection.
